# Scrabble
COMP90015: Distributed Systems, Semester 2, 2018, Assignment 2

## Command-line arguments
Run server as java -jar WordGameServer.jar <port number>
No args required for Client
