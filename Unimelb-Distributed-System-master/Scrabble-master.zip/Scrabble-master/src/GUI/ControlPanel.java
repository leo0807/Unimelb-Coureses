package GUI;

import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JTextArea;

public class ControlPanel extends JPanel 
{


	public ControlPanel()
	{
		initialize();
	}
	
	public Dimension getPreferredSize() {
        return new Dimension(100, 660);
    }
	
	private void initialize()
	{
		/*
		textArea = new JTextArea("", 15, 18);
		textArea.setEditable(false);
		add(textArea);
		*/
	}
	
	
}
