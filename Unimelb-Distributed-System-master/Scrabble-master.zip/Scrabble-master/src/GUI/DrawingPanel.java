package GUI;

import client.ScrabbleClient;

import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class DrawingPanel extends JPanel implements MouseListener
{
	private char[][] board = new char[20][20];
	private int isBlank = 0;
	private ScrabbleClient client;
	private MainWindow mainWindow;

	private boolean mouseListenerEnable = true;

    public void setMouseListenerEnable(boolean mouseListenerEnable) {
        this.mouseListenerEnable = mouseListenerEnable;
    }

    private String messageText;
	
	public DrawingPanel(ScrabbleClient client, MainWindow window) {
		this.client = client;
		this.mainWindow = window;
		// blank board
		for(int y=0;y<20;y++) 
		{
			for(int x=0;x<20;x++) 
			{
				board[y][x] = ' ';
			}
		}
		
		
		// this.client.getInitialBoard();
        isBlank = 0;
        addMouseListener(this);

    }
	
	public Dimension getPreferredSize() {
        return new Dimension(660, 660);
    }
	

	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		// Draw rectangle for board
		g.setColor(Color.BLACK);
		g.drawRect(30, 30, 600, 600);
		
		// Fill the board
		Color ScrabbleGreen = new Color(35, 80, 31);
		g.setColor(ScrabbleGreen);
		g.fillRect(30, 30, 600, 600);
		
		// Draw the grid
		g.setColor(Color.BLACK);
		
		for (int i = 0; i < 20; i++)
		{
			g.drawLine(30, (i * 30) + 30, 630, (i * 30) + 30);
		}
		
		for (int j = 0; j < 20; j++)
		{
			g.drawLine((j * 30) + 30, 30, (j * 30) + 30, 630);
		}
		
		if (isBlank == 0)
		{
			// Place the tiles
			for(int y=0;y<20;y++) 
			{
				for(int x=0;x<20;x++) 
				{
					char currentChar = board[y][x];
					if (currentChar != ' ')
					{
						BufferedImage tile = null;
						String imagePath = "/img/" + currentChar + ".png";
						try 
						{
							tile = ImageIO.read(MainWindow.class.getResource(imagePath));
							
						}
						catch (IOException ex)
						{
							// Something bad.
						}
						
						g.drawImage(tile, (x * 30) + 30, (y * 30) + 30, null); 
					}
				}
			}
			
			
			
			
		}
		
		
		
		
	}
	
	@Override
	public void mouseClicked(MouseEvent arg0) {
		// Not in use
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// Not in use
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// Not in use
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// Not in use
		
	}


	// Logic when mouse is pressed.
	@Override
	public void mousePressed(MouseEvent e) {

	    if (!mouseListenerEnable){
	        // show not your turn
            showMessageDialog(null, "Not Your Turn.");
	        return;
        }
	    // Check if mouse clicked is within bounds.
		if (e.getX() >= 30 && e.getY() >= 30 && e.getX() <= 630 && e.getY() <= 630)
		{
			int x = (e.getX() - 30) / 30;
			int y = (e.getY() - 30) / 30;
			// Show dialog for user to choose options.
			LetterInputDialog dialog = new LetterInputDialog();
			char letter = dialog.showDialog(x, y);

			// If letter is chosen.
			if (letter != 0) {
				// Send move to server.
				System.out.println("making move...");
				makeMove(x, y, letter);
				System.out.println("move sent to server.");
			}
			else			{
				String errorMsg = messageText;
				showMessageDialog(null, errorMsg, "Invalid Move", 0);
			}
		}
	}

	/**
	 * Helper Functions
	 * - makeMove -- sends move to server.
	 * - showAffectedWords -- show affected words on game log.
	 * - getNewBoard -- request new board from server.
	 */
	private void makeMove(int x, int y, char letter){
		client.makeMove(x, y, letter);
	}

	public void setInitialBoard(char[][] board)
	{
		this.board = board;
		System.out.println("Set initial board OK");
	}
	private void getScore(){
		int score = client.getScore();
		mainWindow.updateScore(score);
	}

	public void setBoard(char[][] board){
	    this.board = board;
    }
}