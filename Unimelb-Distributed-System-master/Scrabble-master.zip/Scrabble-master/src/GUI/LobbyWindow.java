package GUI;

import static javax.swing.JOptionPane.showMessageDialog;
import static javax.swing.JOptionPane.showConfirmDialog;

import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

import client.ScrabbleClient;

import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ListSelectionModel;

public class LobbyWindow extends JFrame{

	private ScrabbleClient client;
	private JList list;
	private DefaultListModel listModel;
	private JLabel lblWelcome;
	
	/**
	 * Launch the application.
	 */
	
/*
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LobbyWindow window = new LobbyWindow(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
*/
	
	/**
	 * Create the application.
	 */
	public LobbyWindow(ScrabbleClient client) {
		initialize();
		setVisible(true);
		this.client = client;
		
		Runnable myRunnable =
			    new Runnable(){
			        public void run(){
			        	client.lobbyListen(LobbyWindow.this);
			        }
			    };

		Thread thread = new Thread(myRunnable);
		thread.start();
		
		lblWelcome.setText("Welcome " + client.getPlayerName());
		setTitle("Lobby - " + client.getPlayerName());
	
		
		// Wait continuously
		
	}

	public void gameStart()
	{
		showMessageDialog(null, "Game is ready to start.");
		dispose();
		MainWindow mainWindow = new MainWindow(client);
		//mainWindow.makeGrid(client);
	
	}
	
	public void showNoPlayerError()
	{
		showMessageDialog(null, "No players accepted your invitation.", "Insufficient Players", JOptionPane.WARNING_MESSAGE);
	}
	
	public void updatePlayers(ArrayList<String> players)
	{
		listModel.clear();
		for (String playerName: players)
		{
			if (!playerName.equals(client.getPlayerName()))
			listModel.addElement(playerName);
		}
	}
	
	public int receiveInvitation(String inviter)
	{
		int choice = showConfirmDialog(null, "You have invited to a game hosted by " + inviter + ". Do you accept this invitation?");
		if (choice == JOptionPane.YES_OPTION)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		int width = (Toolkit.getDefaultToolkit().getScreenSize().width - 400) / 2;
		int height = (Toolkit.getDefaultToolkit().getScreenSize().height - 400) / 2;
		setBounds(100, 100, 324, 494);
		setLocation(width, height);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		JLabel lblUsersAvailableTo = new JLabel("Users available to play:");
		lblUsersAvailableTo.setBounds(22, 52, 147, 16);
		getContentPane().add(lblUsersAvailableTo);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(22, 73, 200, 200);
		getContentPane().add(scrollPane);
		
		listModel = new DefaultListModel();
		list = new JList(listModel);
		scrollPane.setViewportView(list);
		
		JButton btnStartGame = new JButton("Invite");
		btnStartGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Get selected 
				if (list.getSelectedIndex() != -1)
				{
				ArrayList<String> selectedPlayers = new ArrayList<String>();
				
				selectedPlayers.add(client.getPlayerName());
				selectedPlayers.addAll(list.getSelectedValuesList());
				client.invitePlayers(selectedPlayers);
				
				/*
				Runnable gameListenHelper =
					    new Runnable(){
					        public void run(){
					        	client.gameListen(LobbyWindow.this);
					        }
					    };

				Thread thread = new Thread(gameListenHelper);
				thread.start();
				*/
				
				}
				else
				{
				showMessageDialog(null, "No players selected.");
				}
				
			}
		});
		btnStartGame.setBounds(22, 286, 97, 25);
		getContentPane().add(btnStartGame);
		
		lblWelcome = new JLabel("Welcome player");
		lblWelcome.setBounds(22, 13, 260, 16);
		getContentPane().add(lblWelcome);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				client.disconnect();
				dispose();
				
			}
		});
		btnExit.setBounds(131, 286, 97, 25);
		getContentPane().add(btnExit);
		
		JLabel lblHintPushShift = new JLabel("Hint: Push SHIFT to select multiple players");
		lblHintPushShift.setBounds(22, 33, 260, 16);
		getContentPane().add(lblHintPushShift);
	}
}

