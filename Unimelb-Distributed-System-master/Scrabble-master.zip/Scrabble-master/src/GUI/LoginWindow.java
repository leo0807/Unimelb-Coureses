package GUI;

import static javax.swing.JOptionPane.showMessageDialog;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;

import client.ScrabbleClient;
import javax.swing.SwingConstants;

public class LoginWindow extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField txtUsername;
	private JButton okButton;
	private JButton cancelButton;
	private ScrabbleClient client;
	private int port = 1235;
	private String host = "localhost";
	private JLabel lblHost;
	private JTextField txtHost;
	private JTextField txtPort;
	private JFrame frame;
	private JLabel lblNewLabel;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    LoginWindow dialog = new LoginWindow();
                    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
                    dialog.setVisible(true);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

	}

	/**
	 * Constructor
	 */
	public LoginWindow() {
		setTitle("Distributed Word Game - Login");

		initialize();

	}


	/**
	 * Helper functions
	 */

	// Initialize GUI
	private void initialize(){
		// Set up display: text and buttons.
		displaySetUp();
		// Added button listeners.
		loginButtonAction();
		cancelButtonAction();
	}
	

	private void displaySetUp(){
		int width = (Toolkit.getDefaultToolkit().getScreenSize().width - 400) / 2;
		int height = (Toolkit.getDefaultToolkit().getScreenSize().height - 400) / 2;
		setBounds(100, 100, 634, 607);
		setLocation(width, height);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(240, 248, 255));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);	
		{
			lblHost = new JLabel("Host:");
			lblHost.setBounds(174, 278, 40, 40);
			contentPanel.add(lblHost);
		}
		{
			txtHost = new JTextField();
			txtHost.setBounds(251, 287, 116, 22);
			contentPanel.add(txtHost);
			txtHost.setColumns(10);
		}
		{
			JLabel lblUsername = new JLabel("Your name:");
			lblUsername.setBounds(156, 335, 74, 16);
			contentPanel.add(lblUsername);
		}
		{
			txtUsername = new JTextField();
			txtUsername.setBounds(251, 332, 116, 22);
			contentPanel.add(txtUsername);
			txtUsername.setColumns(10);
		}
		
		JLabel lblPort = new JLabel("Port:");
		lblPort.setBounds(174, 378, 56, 16);
		contentPanel.add(lblPort);
		
		txtPort = new JTextField();
		txtPort.setBounds(251, 375, 116, 22);
		contentPanel.add(txtPort);
		txtPort.setColumns(10);
		{
			lblNewLabel = new JLabel("");
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel.setLabelFor(this);
			lblNewLabel.setBackground(Color.GRAY);
			lblNewLabel.setIcon(new ImageIcon(LoginWindow.class.getResource("/img/2 .png")));
			lblNewLabel.setBounds(97, 21, 389, 245);
			contentPanel.add(lblNewLabel);
		}
		
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}


	// Button listeners
	private void loginButtonAction(){
		okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	
            	

            	if ((txtUsername.getText().isEmpty() == false) && (txtHost.getText().isEmpty() == false) && (txtPort.getText().isEmpty() == false))
				{
				int port = Integer.parseInt(txtPort.getText());
//				int port = 0;
				if (port < 65535)
				{
					
				      	String playerName = txtUsername.getText();
		                host = txtHost.getText();
		                port = Integer.valueOf(txtPort.getText());
//						host = "localhost";
//						port = 1234;

		                // Create new client.
		                client = new ScrabbleClient(playerName);
		                // Connect to server and return server message.
		                String message = client.connect(playerName, host, port);
		                // System.out.println(message);

		                if (message.equalsIgnoreCase("Welcome to Scrabble!")){
							dispose();
							//
							LobbyWindow lobbyWindow = new LobbyWindow(client);
									
		                }
		                else if (message.equalsIgnoreCase("userexists"))
		                {
		                	showMessageDialog(null, "A user already exists with your name. Please choose another name.", "Error", 0);
		                }
		                else {
		                	showMessageDialog(null, message, "Error", 0);
		                	
		                }
					
				}
				else
				{
					showMessageDialog(null, "Port numbers must be between 0 and 65535.");
				}
			}
			else
			{
				showMessageDialog(null, "You must insert both a server address, port number and a username.");
			}
            	
            	
            	
            	
          
            }
        });
	}

	private void cancelButtonAction(){
	    cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }
}
