package GUI;

import game.Player;
import org.json.simple.JSONObject;
import client.ScrabbleClient;

import java.awt.EventQueue;
import javax.swing.*;
import java.awt.BorderLayout;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

import static javax.swing.JOptionPane.showConfirmDialog;
import static javax.swing.JOptionPane.showMessageDialog;
import java.awt.Toolkit;
import java.util.ArrayList;

public class MainWindow extends JFrame {

	private DrawingPanel drawingPanel;
	private ControlPanel controlPanel;
	private JScrollPane scrollPane;
	private JTable table;
	private JButton btnPass;
	private JButton btnExitGame;
	private JTextArea textArea;
	private JLabel lblPlayerName;

	private MainWindow mainWindow;
	private ScrabbleClient client;
	private boolean yourTurn;
	private String currentPlayer;

	
	/**
	 * Launch the application.
	 */
	/*
	public void makeGrid(ScrabbleClient client) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					System.out.println("Running thread.");
					MainWindow window = new MainWindow(client);
					window.setVisible(true);
                    window.addGameMsg("You are connected.");
                } catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	*/

	/**
	 * Create the application.
	 */
	public MainWindow(ScrabbleClient client) {

        setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindow.class.getResource("/img/a.png")));

        
		setResizable(false);
        this.client = client;
        initialize(this);
        addGameMsg("Game started.");


        Runnable myRunnable =
			    new Runnable(){
			        public void run(){
			        	client.gameListen(MainWindow.this);
			        }
			    };

		Thread thread = new Thread(myRunnable);
		thread.start();
		
		currentPlayer = client.getPlayerName();
		String playerString = "Player: " + currentPlayer;
		lblPlayerName.setText(playerString);
		setTitle("Distributed Word Game (by Team A++) - " + playerString);
		
		setVisible(true);

    }

	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(MainWindow window) {
		
		
		setBounds(0, 0, 900, 700);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		drawingPanel = new DrawingPanel(this.client, window);
		getContentPane().add(drawingPanel, BorderLayout.WEST);

        controlPanel = new ControlPanel();
		getContentPane().add(controlPanel);
		controlPanel.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(30, 39, 152, 197);
		controlPanel.add(scrollPane);


        // Set up table
		table = new JTable() {
			public boolean isCellEditable(int row, int column) {                
                return false;               
        }
		};
		
//		table.setModel(new DefaultTableModel(
//			new Object[][] {
//				{client.getPlayerName(), 0},
//			},
//			new String[] {
//				"Player", "Score"
//			}
//		) {
//			Class[] columnTypes = new Class[] {
//				String.class, Integer.class
//			};
//			public Class getColumnClass(int columnIndex) {
//				return columnTypes[columnIndex];
//			}
//		});

		scrollPane.setViewportView(table);
		table.setPreferredScrollableViewportSize(table.getPreferredSize());
		table.setFillsViewportHeight(true);
		
		btnPass = new JButton("Pass");
		btnPass.setBounds(55, 576, 117, 25);
		controlPanel.add(btnPass);
		passButtonAction();
		
		btnExitGame = new JButton("Exit Game");
		btnExitGame.setBounds(55, 614, 117, 25);
		controlPanel.add(btnExitGame);
		exitButtonAction();

		
		JLabel lblGameLog = new JLabel("Game log:");
		lblGameLog.setBounds(76, 249, 71, 16);
		controlPanel.add(lblGameLog);
		
		JScrollPane scrollPane2 = new JScrollPane();
		scrollPane2.setBounds(12, 278, 188, 285);
		controlPanel.add(scrollPane2);
		
		textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setLineWrap(true);
		scrollPane2.setViewportView(textArea);
		
		lblPlayerName = new JLabel("Player:");
		lblPlayerName.setBounds(12, 13, 188, 16);
		controlPanel.add(lblPlayerName);
		

			
	}

	private void passButtonAction(){
		btnPass.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (yourTurn == true)
				{
					client.makePass();
				}
				else 
				{
					showMessageDialog(null, "You can't pass when it's not your turn.", "Prohibited Action", 2);
				}
				
			}
		});
	}

	private void exitButtonAction(){
		btnExitGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Do some elegant exiting
				// Send message to server to disconnect.
				client.gameOverMessage();
				client.disconnect();
				dispose();
			}
		});
	}

	public void updateScore(int score)
	{
		table.setValueAt(score, 0, 1);
		
	}
	
	public void addGameMsg(String msg)
	{
		String currentText = textArea.getText();
		if (!currentText.equals(""))
		{
		textArea.setText(currentText + "\n" + msg);
		}
		else
		{
		textArea.setText(msg);	
		}
		}
	
	public void setInitialBoard(char[][] board)
	{
		drawingPanel.setInitialBoard(board);
	}

	public int receiveMoveReview(String turnPlayerName, ArrayList<String> affectedWords) {
        String message = turnPlayerName + " puts down:";
        for (int i = 0; i < affectedWords.size(); i++) {
            message += " " + affectedWords.get(i);
        }
        message += ". Is this a valid move?";
        int choice = showConfirmDialog(null, message);
        if (choice == JOptionPane.YES_OPTION) {
            return 1;
        } else {
            return 0;
        }
    }

	public void updatePlayerList(ArrayList<String> playerList)
	{
		
	}
	
	public void updatePlayerScores(ArrayList<Integer> playerScores)
	{
	}
	
	public void disableGameFunctions()
	{
		yourTurn = false;
		//disable all game functions.
        //mouse click listener disabled? is that possible.
        drawingPanel.setMouseListenerEnable(false);
        // TODO: Block pass button
        setTitle("Distributed Word Game - other player's turn");

    }
	
	public void enableGameFunctions()
	{
		yourTurn = true;
		//enable all game functions if not already.
        drawingPanel.setMouseListenerEnable(true);
        // Visual warning
        showMessageDialog(null, "It's now your turn!");
        setTitle("Distributed Word Game - Your turn");
    }
	
	public int showVotingWindow(String playerName, String words)
	{
		return 0;
	}

	public void initPlayerTable(ArrayList<String> playerList){
	    /*
	    Initiate player table when game starts.
	     */

		int numPlayers = playerList.size();
		int playerNameColumn = 0;
		int playerScoreColumn = 1;
		Object[][] playerListObject = new Object[numPlayers][2];
		for (int i=0; i<numPlayers;i++){
			//playerName
			playerListObject[i][playerNameColumn] = playerList.get(i);
			//playerScore
			playerListObject[i][playerScoreColumn] = 0;

		}

		table.setModel(new DefaultTableModel(
				playerListObject,
				new String[] {
						"Player", "Score"
				}
		) {
			Class[] columnTypes = new Class[] {
					String.class, Integer.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
	}

	public void updateScoreTable(ArrayList<Integer> gamePlayerScoresList){
	    /*
	    Update score table for all players.
	     */
	    int playerScoreColumn = 1;
	    for (int i=0; i<gamePlayerScoresList.size(); i++){
	        int score = gamePlayerScoresList.get(i);
            table.setValueAt(score, i, playerScoreColumn);
        }

    }

    public void updateBoard(char[][] updatedBoard){
        drawingPanel.setBoard(updatedBoard);
        drawingPanel.repaint();
    }

    public void gameOver(Player winner)
    {
    	String winnerName = winner.getName();
    	int winnerScore = winner.getScore();
    	showMessageDialog(null, "Game over. " + winnerName + " wins with a score of " + winnerScore);
    	client.disconnect();
    	dispose();
    }

    public void gameOverName(String topPlayerName, int topPlayerScore){
		showMessageDialog(null, "Game over. " + topPlayerName + " wins with a score of " + topPlayerScore);
		dispose();	}
}


