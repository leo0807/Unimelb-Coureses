package client;

import game.Player;
import org.json.simple.JSONObject;

import GUI.LobbyWindow;
import GUI.MainWindow;

import java.io.*;
import java.net.*;
import java.text.ParseException;
import java.util.ArrayList;

public class ScrabbleClient {

    private String playerName;
    private String messageText;
    private boolean gameStarted = false;
    private boolean gameEnded = false;

    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;

    private LobbyWindow lobbyWindow;
    private MainWindow mainWindow;
 
    public String getPlayerName() {
        return playerName;
    }

    public void setLobbyWindow(LobbyWindow lobbyWindow){
        this.lobbyWindow = lobbyWindow;
    }

    public ScrabbleClient(){}

    public ScrabbleClient(String playerName){
        this.playerName = playerName;
        System.out.println("Player Name: " + this.playerName);
    }

    /**
     * Login Window
     * - connect
     */
    public String connect(String playerName, String host, int port){
        try {
            // Make connection with server
            socket = new Socket(host, port);
            System.out.println("Connected to server.");

            getObjectStreams();

            // Send connect message to server
            String command = "connect";
            JSONObject connectMessage = new JSONObject();
            connectMessage.put("command", command);
            connectMessage.put("player", playerName);
//            System.out.println(connectMessage);
            out.writeObject(connectMessage);

            //Accept welcome message from server.
            JSONObject welcomeMessage = (JSONObject) in.readObject();
            String message = (String) welcomeMessage.get("message");
            return message;

        }catch(UnknownHostException ukhe){
            System.out.println(ukhe);
            return "Unknown host. Are you sure you have the right server address?";
        }catch(ConnectException ce){
            System.out.println(ce);
//            System.out.println("Unable to connect to server.");
            return "Unable to connect to server. Are you sure you have the right server address and the server is running?";
        }catch(ClassNotFoundException cnfe){
            System.out.println(cnfe);
//            System.out.println("Class not found from reading object from server.");
            return "Class not found from reading object from server.";
        }catch(EOFException eofe){
            System.out.println(eofe);
            return "Unable to receive welcome message from server.";
        }catch(IOException ioe){
            System.out.println(ioe);
            return "IO Exception.";
        }
    }

    /**
     * Lobby Window
     * - lobbyListen -- continuously listen to server input for lobby window.
     * - invitePlayers -- to be called by inviter.
     */

    public void lobbyListen(LobbyWindow lobbyWindow){
        // set up lobby window.
        setLobbyWindow(lobbyWindow);
        // continuously listening to server's messages
        JSONObject serverInput;
        do{
            // Get server input
            serverInput = readServerInput();
            // Parse server input
            if (!serverInput.isEmpty()){
                lobbyParseServerInput(serverInput);
            }
        }while(!gameStarted);
    }

    public void lobbyParseServerInput(JSONObject serverInput){
        /*
        Parse server input
        - updatePlayersList
         */
        String command = (String) serverInput.get("command");

        switch(command){
            case "updatePlayersList":
                lobbyAddPlayer(serverInput);
                break;
            case "invite":
                lobbyAccept(serverInput);
                break;
            case "startGame":
                lobbyGameStart();
                break;
            case "notEnoughPlayers":
                lobbyNotEnoughPlayers();
                break;
        }

    }

    public void lobbyAddPlayer(JSONObject serverInput){
        /*
        Update lobby's player list.
         */
        ArrayList<String> newPlayersList = (ArrayList<String>) serverInput.get("newPlayersList");
        lobbyWindow.updatePlayers(newPlayersList);

    }

    public void invitePlayers(ArrayList<String> invitedPlayersList){
        /*
        Sends all selected players to server.
         */
        // Construct startGame message.
        JSONObject startGameMessage = new JSONObject();

        startGameMessage.put("command", "invitePlayers");

        startGameMessage.put("invitedPlayersList", invitedPlayersList);

        try{
            out.writeObject(startGameMessage);
        }catch(IOException ioe){
            System.out.println("IOException: Unable to send start game message.");
        }
    }

    public void lobbyAccept(JSONObject serverInput){
        /*
        Ask for acceptance to invite from GUI and send reply to server.
         */

        // Get inviter name.
        String inviter = (String) serverInput.get("inviter");
        // Send invite to GUI.
        int accept = lobbyWindow.receiveInvitation(inviter);


        // Construct accept message.
        JSONObject acceptMessage = new JSONObject();
        acceptMessage.put("command", "acceptPlayer");
        if (accept == 1){
            acceptMessage.put("acceptedPlayer", playerName);

        }else{
            // playername can't be none.
            acceptMessage.put("acceptedPlayer", "None");
        }
        // send accept message to server.
        try{
            out.writeObject(acceptMessage);
        }catch(IOException ioe){
            System.out.println("IOException: accept message can't be sent.");
        }

    }

    public void lobbyGameStart(){
        lobbyWindow.gameStart();
        // ends lobbyListen loop.
        gameStarted = true;
    }

    public void lobbyNotEnoughPlayers(){
        lobbyWindow.showNoPlayerError();
    }


    /**
     * Game Window
     * - gameListen -- continuously listen to server input for game window.
     */
    private void setMainWindow(MainWindow mainWindow) {
        this.mainWindow = mainWindow;

    }

    public void gameListen(MainWindow mainWindow){
        // set up lobby window.
        setMainWindow(mainWindow);
        // continuously listening to server's messages
        JSONObject serverInput;
        do{
            // Get server input
            serverInput = readServerInput();
            // Parse server input
            if (!serverInput.isEmpty()){
                gameParseServerInput(serverInput);
            }
        }while(!gameEnded);
    }

	public void gameParseServerInput(JSONObject serverInput){
        /*
        Parse server input
        - updatePlayersList
         */
        String command = (String) serverInput.get("command");

        switch(command){
            case "initialize":
                // init board
                gameInitBoard(serverInput);
            	// init player list
                gameInitPlayers(serverInput);
                break;
            case "turn":
                gameTurnParser(serverInput);
                break;
            case "reviewTurnPlayer":
                gameReviewTurnPlayer(serverInput);
                break;
            case "updateScore":
                //update game player's score
                gameUpdateScore(serverInput);
                break;
            case "updateBoard":
                //update board
                gameUpdateBoard(serverInput);
                break;
            case "gameOver":
            	gameOver(serverInput);
            	break;
            case "gamelogmessage":
                gameLogUpdate(serverInput);
                break;
            case "endGame":
                gameEndGame(serverInput);
        }

    }

    private void gameEndGame(JSONObject serverInput){
        // show winner.
        String topPlayerName = (String) serverInput.get("topPlayerName");
        int topPlayerScore = (Integer) serverInput.get("topPlayerScore");
        gameEnded = true;
        mainWindow.gameOverName(topPlayerName, topPlayerScore);
    }
	
	private void gameOver(JSONObject serverInput) {
		Player highestScorer = (Player) serverInput.get("winner");
		mainWindow.gameOver(highestScorer);		
	}
	
    //Initialize
    private void gameInitBoard(JSONObject serverInput) {
        char[][] initialBoard = (char[][]) serverInput.get("initialBoard");

        // update board in GUI.

	}

	private void gameInitPlayers(JSONObject serverInput){
        ArrayList<Player> gamePlayerList = (ArrayList<Player>) serverInput.get("gamePlayerList");
        ArrayList<String> gamePlayerStringList = new ArrayList<>();
        for (int i=0; i<gamePlayerList.size();i++){
            gamePlayerStringList.add(gamePlayerList.get(i).getName());
            }

        //update players in GUI.
        mainWindow.initPlayerTable(gamePlayerStringList);
    }

    // turn
    private void gameTurnParser(JSONObject serverInput){
        // check if turn == client's name
        String turnPlayerName = (String) serverInput.get("turnPlayerName");
        boolean turn =  turnPlayerName.equalsIgnoreCase(this.playerName);
        if (turn){
            // allow all functions
            System.out.println("Enable all functions in game.");
            mainWindow.enableGameFunctions();
        }else{
            //disable all game functions.
            System.out.println("Disable all functions in game.");
            mainWindow.disableGameFunctions();
        }

    }
    // reviewTurnPlayer
    private void gameReviewTurnPlayer(JSONObject serverInput){
        /*
        Command: reviewTurnPlayer
        Show pop up box to client
         */
        String turnPlayerName = (String) serverInput.get("turnPlayerName");
        ArrayList<String> affectedWords = (ArrayList<String>) serverInput.get("affectedWords");

        //show turnPlayer name and affectedWords on pop up.
        System.out.println("TurnPlayer: " + turnPlayerName);
        System.out.println("AffectedWords: " + affectedWords.toString());
        int review = mainWindow.receiveMoveReview(turnPlayerName, affectedWords);

        // sends reviewedMoveMessage to server.
        JSONObject reviewedMoveMessage = new JSONObject();
        reviewedMoveMessage.put("command", "reviewedMove");
        if (review == 1){
            reviewedMoveMessage.put("reviewedMove", 1);
        }else{
            reviewedMoveMessage.put("reviewedMove", 0);
        }
        sendServerMessage(reviewedMoveMessage, "sending reviewed move message.");

    }
    //updateScore
    private void gameUpdateScore(JSONObject serverInput){
//        ArrayList<Player> gamePlayerList = (ArrayList<Player>) serverInput.get("updatedGamePlayersList");

        // update score in GUI.
        // TO REMOVE
        ArrayList<Integer> gamePlayerScoresList = (ArrayList<Integer>) serverInput.get("updatedGameScoresList");
        System.out.println(gamePlayerScoresList.toString());
        mainWindow.updateScoreTable(gamePlayerScoresList);
    }

    //updateBoard
    private void gameUpdateBoard(JSONObject serverInput){
        /*
        Update and repaints board for client.
         */
        char[][] updatedBoard = (char[][]) serverInput.get("updatedBoard");
        mainWindow.updateBoard(updatedBoard);
    }

    public void gameLogUpdate(JSONObject serverInput){
        /*
        update gamelog for client.
         */
        String message = (String) serverInput.get("message");

        mainWindow.addGameMsg(message);

    }


    /**
     * Main Window
     * - makeMove
     */


    public void makeMove(int x, int y, char letter){
        //Construct move in JSON.
        JSONObject makeMoveMessage = new JSONObject();
        makeMoveMessage.put("command", "makeMove");
        makeMoveMessage.put("x", x);
        makeMoveMessage.put("y", y);
        makeMoveMessage.put("letter", letter);
        //Send message to server to make move.
        sendServerMessage(makeMoveMessage, "makeMoveMessage.");
    }



    // (!) to be called by pass button.
    public void makePass(){
        JSONObject makePassMessage = new JSONObject();
        makePassMessage.put("command", "makePass");

        sendServerMessage(makePassMessage, "makePassMessage");

    }

    // to be called by GUI on dispose.
    public void gameOverMessage(){
        /*
        Send game over message to server.
         */
        JSONObject gameOverMessage = new JSONObject();
        gameOverMessage.put("command", "gameOver");

        sendServerMessage(gameOverMessage, "game over message.");
    }





    /**
     * Code from previous deadline.
     */



    public char[][] getBoardUpdate(){
        try{
            // Get reply from server.
            JSONObject newBoard = (JSONObject) in.readObject();
            char[][] board = (char[][]) newBoard.get("currentBoard");
            return board;

        }catch(ClassNotFoundException cnfe){
            System.out.println(cnfe);
            System.out.println("Unable to read new board object from server.");
        }catch(IOException ioe){
            System.out.println(ioe);
        }
        return null;
    }

    public int getScore(){
        int score = 0;
        try{
            JSONObject scoreReply = (JSONObject) in.readObject();
            System.out.println(scoreReply);
            score = (Integer) scoreReply.get("score");
            return score;
        }catch(IOException ioe){
            System.out.println("IOE from get score.");
        }catch(ClassNotFoundException cnfe){
            System.out.println("CNFE from get score.");
        }
        return score;
    }

    public void disconnect(){
        //Construct JSON disconnect message.
        JSONObject disconnectMessage = new JSONObject();
        disconnectMessage.put("command", "disconnect");
        //Send disconnect message to server.
        try {
            out.writeObject(disconnectMessage);
        }catch(IOException ioe){
            System.out.println("Unable to send disconnect message to server.");
        }
        // Close sockets and streams.
        close();
    }
    
    public String getMessageText()
    {
    	return messageText;
  
    }

    public JSONObject readServerInput(){
        /*
        Returns server input in JSONObject type.
         */

        JSONObject serverInput = new JSONObject();
        try{
            serverInput = (JSONObject) in.readObject();
        }catch(EOFException eofe){
            System.out.println("End of File Exception: Reading server input.");
        }catch(IOException ioe){

        }catch(ClassNotFoundException cnfe){
            System.out.println("");
        }
        return serverInput;
    }


    /**
     * Misc. Helper functions:
     * - getObjectStreams -- get object streams from socket once connected.
     */

    private void sendServerMessage(JSONObject serverMessage, String errorMessage){
        try{
            out.writeObject(serverMessage);
        }catch(IOException ioe){
            System.out.println("IOException: " + errorMessage);
        }
    }

    private void getObjectStreams(){
        try {
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
        }catch(IOException ioe){
            System.out.println("Unable to get streams from server.");
        }
    }
    private void close(){
        try {
            out.close();
            in.close();
            socket.close();
        }catch(IOException ioe){
            System.out.println(ioe);
            System.out.println("Unable to close streams and sockets.");
        }

    }

}
