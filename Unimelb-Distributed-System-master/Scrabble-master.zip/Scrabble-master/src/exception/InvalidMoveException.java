package exception;

public class InvalidMoveException extends Exception {
	/**
	 * A wrapper exception class to handle invalid moves exceptions. This exception
	 * will also add an extra message as a preface: "Invalid Move!".
	 */
	private static final long serialVersionUID = 1L;

	public InvalidMoveException() {
		super();
	}
	
	private static String prefaceErrorMessage(String message) {
		return "Invalid move! " + message;
	}
	
	public InvalidMoveException(String message) {
		super(prefaceErrorMessage(message));
	}
	
	public InvalidMoveException(String message, Throwable cause) {
		super(prefaceErrorMessage(message),cause);
	}
	
	public InvalidMoveException(String message, Exception e) {
		super(prefaceErrorMessage(message),e);
	}
	
}
