package exception;

public class InvalidNumberPlayersException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;
	
	private final static String prefaceInvalidNumberPlayers = "Invalid number of players! ";
	
	public InvalidNumberPlayersException() {
		super();
	}
	
	private static String prefacedMsg(String msg) {
		return prefaceInvalidNumberPlayers+msg;
	}
	
	public InvalidNumberPlayersException(String msg) {
		super(prefacedMsg(msg));
	}
	
	public InvalidNumberPlayersException(String msg, Throwable t) {
		super(prefacedMsg(msg), t);
	}
	
	public InvalidNumberPlayersException(String msg, Exception e) {
		super(prefacedMsg(msg), e);
	}
}
