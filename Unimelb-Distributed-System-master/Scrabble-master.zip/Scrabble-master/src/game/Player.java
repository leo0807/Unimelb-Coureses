package game;

import java.io.Serializable;

//Represent the player controlling the game (some other info for player should be added here)
public class Player implements Serializable {
	private String name;
	private int playerIndex;
    private int score;

	public Player(String name) {
		this.name = name;
		score = 0;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
	public void addScore(int adder) {
		setScore(getScore() + adder);
	}

	public int getPlayerIndex(){
	    return playerIndex;
    }

	public void setPlayerIndex(int playerIndex	){
		this.playerIndex = playerIndex;
	}
}
