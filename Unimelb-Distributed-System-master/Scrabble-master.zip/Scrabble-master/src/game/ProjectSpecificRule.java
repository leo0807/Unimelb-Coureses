package game;

import java.util.ArrayList;
import java.util.List;

import exception.InvalidMoveException;
import utility.Move;

//Not the best name for a class :)
public class ProjectSpecificRule implements ScrabbleRule {
	public static final int BOARDSIZE_X = 20;
	public static final int BOARDSIZE_Y = 20;
	private static boolean FIRST_MOVE = true;
	
	private List<ArrayList<String>> wordsMadeSoFar = new ArrayList<ArrayList<String>>();
	@Override
	public void evaluate(ScrabbleBoard board, List<Move> listMoves, ArrayList<Player> listPlayers) throws InvalidMoveException{
		//Should handle some errors
		
		//This rule requires player only make one move (i.e. one letter)
		if (listMoves.size() != 1) throw new InvalidMoveException("Should only move a letter/move");
		
		Move move = listMoves.get(0);
		int x = move.getX();
		int y = move.getY();
		Player p = move.getPlayer();
//        System.out.println("ProjectSpecificRule: " + p.getName());
		char letter = move.getLetter();
		int index_player = listPlayers.indexOf(p);
		
		//This should never happen, but better safe than sorry
		//Player making the move should always be in the array list
		if (index_player == -1) throw new InvalidMoveException("Somehow player doesn't exist in the player pool!");
		
		//When it's the first move (no letters on board), allow placing letters at any
		//location on board
		if (FIRST_MOVE) {
			try {
				board.setLetterToTile(x,y,letter);
				validateWord(String.valueOf(letter));
				p.addScore(1);
				ArrayList<String> tmp = new ArrayList<String>();
				tmp.add(String.valueOf(letter));
				wordsMadeSoFar.add(tmp);
				FIRST_MOVE = false;
				return;
			}
			catch (IllegalArgumentException iae) {
				throw new InvalidMoveException(iae.getMessage(), iae);
			}
		}
		
		//Letter has to be placed adjacent to another existing letter on the board
		List<ScrabbleBoard.DIRECTION> lisOftNeighboursWithLetter = 
				board.hasLetterNeighbour(x, y);
		if (lisOftNeighboursWithLetter.isEmpty()) throw new InvalidMoveException("Need to be placed adjacent to a letter!");
		
		//Try to apply move to the board
		try {
			board.setLetterToTile(x, y, letter);
		}
		catch (IllegalArgumentException iae) {
			throw new InvalidMoveException(iae.getMessage(), iae);
		}
		
		//Do not apply the move permanently if the one of the words made by the move is invalid
		if (!checkWordsAcrossAndDown(board,lisOftNeighboursWithLetter,p,x,y)) {
			try {
				
				board.deleteLetter(x,y);
			}
			//this should never go here
			catch (IllegalArgumentException iae){
				throw iae;
			}

		}
		//If it passes all validation, then that move is legal
		//System.out.println("waut" + wordsMadeSoFar);
	}
	
	//Checks if the words connected by the new letter are valid and also updates the score if they were all valid
	private boolean checkWordsAcrossAndDown(ScrabbleBoard board, List<ScrabbleBoard.DIRECTION> listOfDir, Player p, int x, int y) {
		String word = "";
		boolean boolIsValidWordDown = true;
		boolean boolIsValidWordAcross = true;

		ArrayList<String> wordsMadeLastMove = new ArrayList<String>();
		if (listOfDir.contains(ScrabbleBoard.DIRECTION.UP) || listOfDir.contains(ScrabbleBoard.DIRECTION.DOWN)) {
			word = board.searchWord(ScrabbleBoard.DIRECTION.UP, x, y);
			//if searched word consists of a letter or nothing, then don't bother checking for word validity
			if (word.length() > 1) {
				boolIsValidWordDown = validateWord(word);
				if (boolIsValidWordDown) wordsMadeLastMove.add(word);
			}
		}
		if (listOfDir.contains(ScrabbleBoard.DIRECTION.LEFT) || listOfDir.contains(ScrabbleBoard.DIRECTION.RIGHT)) {
			word = board.searchWord(ScrabbleBoard.DIRECTION.LEFT, x, y);
			//if searched word consists of a letter or nothing, then don't bother checking for word validity
			if (word.length() > 1) {
				boolIsValidWordAcross = validateWord(word);
				if (boolIsValidWordAcross) wordsMadeLastMove.add(word);
			}
		}
		
		if (boolIsValidWordDown && boolIsValidWordAcross) {
			for (String w : wordsMadeLastMove) {
				p.addScore(w.length());
			}
			wordsMadeSoFar.add(wordsMadeLastMove);
			return true;
		}
		return false;
	}
	
	//Validate the word (need to be implemented with voting GUI)
	public boolean validateWord(String word) {
		//System.out.println("Validating this word: " + word);
//		TestGame.addGameMessage("Player made word: " + word);




		return true;
	}

	public Player getNextPlayer(ArrayList<Player> alp, Player p) {
		int size = alp.size();
		int currentPlayerIndex = alp.indexOf(p);
		//assuming player always exist in the alp (index never going to be -1)
		return alp.get((currentPlayerIndex+1) % size);
	}
	
	
	//TESTING ONLY
	public ArrayList<String> getWordsMadeLastMove(){
		if (!wordsMadeSoFar.isEmpty()) 
			return wordsMadeSoFar.get(wordsMadeSoFar.size()-1);
		return null;
		
	}


}
