package game;

import java.util.ArrayList;
import java.util.List;

//This class represents the board game itself. It has all functions regarding the positions of the tiles
//and word searching. This could potentially be used both for server (for game logic management) and
//for the client-side as well (checking illegal moves e.g. placing letter on top of other letter)
public class ScrabbleBoard {
	public static enum DIRECTION {UP, DOWN, LEFT, RIGHT};
	
	public static final int ERR_OUT_OF_BOUNDS = -1;
	public static final int ERR_POS_OCCUPIED_BY_LETTER = -2;
	public static final int FAIL = 0;
	public static final int SUCCESS = 1;
	
	private int BoardSizeX;
	private int BoardSizeY;
	
	private Tile[][] BoardTiles;
	
	public ScrabbleBoard(int boardSizeX, int boardSizeY) {
		BoardSizeX = boardSizeX;
		BoardSizeY = boardSizeY;
		BoardTiles = new Tile[BoardSizeX][BoardSizeY];
	}

	public int getBoardSizeX() {
		return BoardSizeX;
	}

	public int getBoardSizeY() {
		return BoardSizeY;
	}
	
	public void init() {
		for (int y=0;y<BoardSizeY;y++) {
			for (int x=0;x<BoardSizeX;x++) {
				BoardTiles[y][x] = new Tile();
			}
		}
	}
	
	public boolean isOutOfBounds(int x, int y) {
		return (x < 0 || y < 0 || x >= BoardSizeX || y >= BoardSizeY);
	}
	
	//This should be checked on the client side as well
	public int isValidLetterPlacement(int x, int y){
		if (isOutOfBounds(x,y)) {
			return ERR_OUT_OF_BOUNDS;
		}
		if (BoardTiles[y][x].hasLetter()) {
			return ERR_POS_OCCUPIED_BY_LETTER;
		}
		return SUCCESS;
	}
	
	public void setLetterToTile(int x, int y, char letter) throws IllegalArgumentException{
		int err = isValidLetterPlacement(x,y);
		if (err == ERR_OUT_OF_BOUNDS) {
			throw new IllegalArgumentException(String.format("Position (%d,%d) is out of bounds!", x,y));
		}
		else if (err == ERR_POS_OCCUPIED_BY_LETTER) {
			throw new IllegalArgumentException(String.format("Position (%d,%d) has been occupied by another letter!", x,y));
		}
		
		try {
			BoardTiles[y][x].setLetter(letter);
		}
		catch (IllegalArgumentException iae) {
			throw iae;
		}
		
	}
	
	public void deleteLetter(int x, int y) throws IllegalArgumentException{
		if (isOutOfBounds(x,y)) {
			throw new IllegalArgumentException(String.format("Position (%d,%d) is out of bounds!", x,y));
		}
		else if (!BoardTiles[y][x].hasLetter()) {
			throw new IllegalArgumentException(String.format("Position (%d,%d) has no letter!", x,y));
		}
		BoardTiles[y][x].setBlank();
	}
	
	/* I'm not sure where to put these next two function, either I should put it here
	 * in this class or put it in ProjectSpecificRule... Ideally, this class should
	 * represent a general Scrabble board so idk if these two functions are too specific
	 * for this particular rule or not.
	 */
	
	//Check if tile (represented in coordinates) has any adjacent tiles that has letter in it
	public List<DIRECTION> hasLetterNeighbour(int x, int y){
		List<DIRECTION> result = new ArrayList<DIRECTION>();
		if (!isOutOfBounds(x-1,y) && BoardTiles[y][x-1].hasLetter()) {
			result.add(DIRECTION.LEFT);
		}
		if (!isOutOfBounds(x+1,y) && BoardTiles[y][x+1].hasLetter()) {
			result.add(DIRECTION.RIGHT);
		}
		if (!isOutOfBounds(x,y-1) && BoardTiles[y-1][x].hasLetter()) {
			result.add(DIRECTION.UP);
		}
		if (!isOutOfBounds(x,y+1) && BoardTiles[y+1][x].hasLetter()) {
			result.add(DIRECTION.DOWN);
		}
		return result;
	}
	
	//Basically, searches for a word from starting coordinate in dir direction
	//If dir is LEFT/RIGHT, it searches for word across the starting point
	//IF dir is UP/DOWN, it searches for word down the starting point
	//(sort of like crossword)
	public String searchWord(DIRECTION dir, int starting_x, int starting_y) {
		int x = starting_x;
		int y = starting_y;
		String word = "";
		
		//Searches word down (find the top most character then traverse to the bottom most character in the same column)
		if (dir == DIRECTION.UP || dir == DIRECTION.DOWN) {
			while (!isOutOfBounds(x,y-1) && BoardTiles[y-1][x].hasLetter()) {
				y--;
			}
			while (!isOutOfBounds(x,y) && BoardTiles[y][x].hasLetter()) {
				word += BoardTiles[y][x].getLetter();
				y++;
			}
		}
		//Searches word across (find the left most character then traverse to the right most character in the same row)
		else if (dir == DIRECTION.LEFT || dir == DIRECTION.RIGHT) {
			while (!isOutOfBounds(x-1,y) && BoardTiles[y][x-1].hasLetter()) {
				x--;
			}
			while (!isOutOfBounds(x,y) && BoardTiles[y][x].hasLetter()) {
				word += BoardTiles[y][x].getLetter();
				x++;
			}
		}
		return word;
	}
	
	//returns the state of the board in array of char
	public char[][] getLettersOnBoard(){
		char[][] board = new char[BoardSizeX][BoardSizeY];
		for(int y=0;y<BoardSizeY;y++) {
			for(int x=0;x<BoardSizeX;x++) {
				board[y][x] = BoardTiles[y][x].getLetter();
			}
		}
		return board;
	}
	
	//for debugging purposes, i guess..
	//Convert the board state into string visualization.
	public String visualizeState() {
		String vis = "";
		for (int y=0;y<BoardSizeY;y++) {
			for (int x=0;x<BoardSizeX;x++) {
				vis += "[" + BoardTiles[y][x].getLetter() + "]";
			}
			vis += "\n";
		}
		return vis;
	}
	
}
