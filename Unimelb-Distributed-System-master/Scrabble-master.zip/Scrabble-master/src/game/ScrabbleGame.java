package game;

import java.util.ArrayList;
import java.util.List;

import exception.InvalidMoveException;
import exception.InvalidNumberPlayersException;
import utility.Move;

public class ScrabbleGame {
	
	private ScrabbleBoard grid;
	private ArrayList<Player> listPlayers;
	private int minimumPlayerRequirement;
	private int maximumPlayerRequirement;
	private ScrabbleRule rule;
	
	private Player currentTurnPlayer;


	private int numPassesWithoutMove = 0;
	private boolean gameEndedLock = false;
	
	public ScrabbleGame(ScrabbleRule rule, int acceptedPlayersNumber) {
		//Create a grid 20x20
		grid = new ScrabbleBoard(ProjectSpecificRule.BOARDSIZE_X ,ProjectSpecificRule.BOARDSIZE_Y);
		grid.init();
		
		this.rule = rule;

		listPlayers = new ArrayList<>();
		
		try {
			setMinimumNumberPlayers(1);
			setMaxNumberPlayers(acceptedPlayersNumber);
		} catch (InvalidNumberPlayersException e) {
			e.printStackTrace();
		}
		
		//This player bit is just for single-player testing purposes
//		listPlayers = new Player[TEST_SINGLE_PLAYER_LIMIT];
//		listPlayers[0] = new Player("Elb Barcs");
	}
	
	private ScrabbleBoard getGrid() {
		return grid;
	}
	
	public void setMaxNumberPlayers(int maxNumber) throws InvalidNumberPlayersException{
		if (maxNumber < minimumPlayerRequirement) {
			throw new InvalidNumberPlayersException("Maximum number should be minNumber <= maxNumber!");
		}
		else {
			maximumPlayerRequirement = maxNumber;
		}
	}
	
	public int getMaxNumberPlayers() {
		return maximumPlayerRequirement;
	}
	
	public void setMinimumNumberPlayers(int minimumNumber) throws InvalidNumberPlayersException {
		if (minimumNumber <= 0 && minimumNumber > getMaxNumberPlayers()) {
			throw new InvalidNumberPlayersException("Minimum number should be 0 < num < maxNumber!");
		}
		else {
			minimumPlayerRequirement = minimumNumber;
		}
	}
	
	public ArrayList<Player> getListOfPlayers(){
		return listPlayers;
	}
	
	public int getCurrentNumPlayers() {
		return getListOfPlayers().size();
	}
	public void addPlayer(Player p) throws InvalidNumberPlayersException {
		if (getMaxNumberPlayers() < getCurrentNumPlayers()+1){
			throw new InvalidNumberPlayersException(String.format("Game is full (Max num of players: %d!)", getMaxNumberPlayers()));	
		}
		else {
			getListOfPlayers().add(p);
		}
	}
	
	//Get whose turn it is currently in the game
	public Player getTurnPlayer() {
		return currentTurnPlayer;
	}

	//Set whose turn it is currently in the game
	public void setTurnPlayer(Player turnPlayer) {
		this.currentTurnPlayer = turnPlayer;
	}
	
	//Get the next player in line after the current turns end according to the rules

	public Player getNextPlayer(Player p) {
		return rule.getNextPlayer(this.listPlayers, p);
	}
	
	//no parameter version of getNextPlayer (next person relative to current player)
	public Player getNextPlayerFromCurrentPlayer() {
		return getNextPlayer(this.currentTurnPlayer);
	}
	
	//Passes the turn to the next player, i.e. set the current player turn to next player
	public void passTurnToNextPlayer(Player p) {
		if (gameEndedLock) return;
		setTurnPlayer(getNextPlayer(p));
	}


	//general case function (maybe we might implement word per player move?)
	public void makeMoveWord(List<Move> listMoves) throws InvalidMoveException{
		if (gameEndedLock) return;
		try {
			rule.evaluate(getGrid(), listMoves, getListOfPlayers());
			passTurnToNextPlayer(listMoves.get(0).getPlayer()); //this should equivalent to passing from current turn's player
			numPassesWithoutMove = 0;
		}
		catch (IllegalArgumentException iae) {
			throw new InvalidMoveException(iae.getMessage(), iae);
		}
	}
	
	//letter per player move
	public void makeMoveLetter(Player player, int x, int y, char letter) throws InvalidMoveException {
		List<Move> listOfOneLetterMove = new ArrayList<Move>();
		listOfOneLetterMove.add(new Move(player,x,y,letter));
		makeMoveWord(listOfOneLetterMove);
	}
	
	//Get the player with the highest score from the list of players
	//Note: If there is a tie/draw, it'll return the player with the lowest index
	public Player getHighestScorer() {
		Player highscorer = new Player("HIGHSCORER");
		highscorer.setScore(Integer.MIN_VALUE);
		for (Player p : getListOfPlayers()) {
			if (p.getScore() > highscorer.getScore()) {
				highscorer = p;
			}
		}
		return highscorer;
	}
	
	//When player presses the "pass" button, it'll move to the next player
	//and start counting how many players has passed this way

	public void passTurnWithoutMakingMove(Player p) {
		passTurnToNextPlayer(p);

		numPassesWithoutMove += 1;
		//if all players have passed without a move, end the game
		if (numPassesWithoutMove >= getMaxNumberPlayers()) {
			endGame();
		}
	}
	
	//Server should periodically (every turn) use this function to see if the
	//game has ended or not.
	//Returns the player with highest score (winner) if the game has ended
	//Returns null if it hasn't end
	public Player checkForGameEnd() {
		if (gameEndedLock) return getHighestScorer();
		else return null;
	}
	
	//End the game, locking some of the functions fro safety
	//				WARNING
	//Please only call this when the game has truly ended! (Already implemented when all players have passed)
	public void endGame() {
		gameEndedLock = true;
	}
	
	
	//FOR TESTING ONLY FUNCTIONS
	public void makeMoveLetter(int x, int y, char letter) throws InvalidMoveException {
		makeMoveLetter(getFirstPlayer(),x,y,letter);
	}
	
	public ScrabbleBoard getBoard() {
		return grid;
	}
	
	public Player getFirstPlayer() {
		return listPlayers.get(0);
	}

	public void setListPlayer(ArrayList<Player> listPlayers){
		ArrayList<Player> alp = new ArrayList<Player>();
		for (Player p : listPlayers) {
			alp.add(p);
		}
	    this.listPlayers = alp;

	    this.setTurnPlayer(this.getFirstPlayer());

    }
	
	public String visualizeBoard() {
		return grid.visualizeState();
	}
	
	public ArrayList<String> getWordsMadeLastMove(){
		return rule.getWordsMadeLastMove();
	}
}
