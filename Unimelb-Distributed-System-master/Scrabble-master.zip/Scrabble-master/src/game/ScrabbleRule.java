package game;

import java.util.ArrayList;
import java.util.List;

import exception.InvalidMoveException;
import utility.Move;

//A rule template for Scrabble (for futher expansion purposes)
public interface ScrabbleRule {
	public void evaluate(ScrabbleBoard board, List<Move> listMoves, ArrayList<Player> listPlayers) throws InvalidMoveException;
	public ArrayList<String> getWordsMadeLastMove();
	public Player getNextPlayer(ArrayList<Player> alp, Player p);

}
