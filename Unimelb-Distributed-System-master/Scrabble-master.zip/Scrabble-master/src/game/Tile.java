package game;

//This class represents a square/tile in the Scrabble board game (so there will be 20x20=400 tiles)
public class Tile {
	public static final char BLANK = ' ';
	private char letter;
	
	public Tile() {
		setBlank();
	}
	
	public boolean hasLetter() {
		return Character.isLetter(letter);
	}
	
	public char getLetter() {
		return letter;
	}
	
	public void setBlank() {
		this.letter = BLANK;
	}
	
	public void setLetter(char letter) throws IllegalArgumentException{
		if (Character.isLetter(letter)) {
			this.letter = Character.toLowerCase(letter);
		}
		else throw new IllegalArgumentException("Setting an invalid char to tile! (Must be an alphabet)");
	}
	
	
}
