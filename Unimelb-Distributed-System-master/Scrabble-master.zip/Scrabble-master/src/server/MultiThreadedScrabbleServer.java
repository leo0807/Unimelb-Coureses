package server;

import client.ScrabbleClient;
import game.Player;
import game.ProjectSpecificRule;
import game.ScrabbleGame;

import java.io.*;
import java.net.*;
import java.util.ArrayList;


public class MultiThreadedScrabbleServer extends ScrabbleServer implements Runnable{
    public void run(){
        System.out.println("Running thread...");
        execute();
        System.out.println(Thread.currentThread().getName() + " ended. Client disconnected. Game over.");
        // Reset game
        return;
    }
    public static int MAXPLAYERS = 4;

    public static void main(String[] args){
//        int port = 1235
        if (args.length != 1){
            throw new IllegalArgumentException("Please register a port number.");
        }


        try{
            int port = Integer.parseInt(args[0]);

            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("Server socket port: " + port);
            Thread serverSocketThread = Thread.currentThread();
            serverSocketThread.setName("Thread-ServerSocket");

            boolean initGame = true;

            // Continuously listen for connections.
            while (true){
                //1. Listen for client's request and create new socket when connected.
                System.out.println("Listening for client connection...");
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected.");

                if (initGame){
                    lobbyServerList = new ScrabbleServer[MAXPLAYERS];
                    System.out.println("New client list initiated.");
                    lobbyPlayerList = new Player[MAXPLAYERS];
                    System.out.println("New Player List initiated.");
                    currentPlayerNumber = 0;
                    initGame = false;
                }

                //2. Create new Server class, set client socket to
                MultiThreadedScrabbleServer server = new MultiThreadedScrabbleServer();
                server.setClientSocket(clientSocket);
                server.setCurrentPlayerIndex(currentPlayerNumber);

//                clientList.add(server);

                //3. Make new thread and execute.
                Thread serverThread = new Thread(server);
                serverThread.start();

                serverSocketThread.sleep(1000);
            }
        }catch(IOException ioe){
            ioe.printStackTrace();
            System.out.println("Unable to make server socket.");
        }catch(InterruptedException ie){
            System.out.println("serverSocketThread's wait is interrupted.");
        }


    }
}
