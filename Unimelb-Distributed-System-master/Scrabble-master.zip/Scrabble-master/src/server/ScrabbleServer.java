package server;

import client.ScrabbleClient;
import exception.InvalidMoveException;
import exception.InvalidNumberPlayersException;
import game.ProjectSpecificRule;
import org.json.simple.JSONObject;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

import game.Player;
import game.ScrabbleGame;
import server.MultiThreadedScrabbleServer;


public class ScrabbleServer {

    private Socket clientSocket;
    private ObjectInputStream in;
    private ObjectOutputStream out;

    public static ScrabbleGame scrabbleGame;
    public static int currentPlayerNumber;
    public static Player[] lobbyPlayerList;
    public static ScrabbleServer[] lobbyServerList;
    public static ArrayList<ScrabbleServer> gameServerList;
    public static ArrayList<Player> gamePlayerList;

    private Player player;
    private boolean disconnect = false;
    private int CONNECTMESSAGESIZE = 2;
    private int currentPlayerIndex;

//    private ArrayList<String> invitedPlayersCounter;
    public static int invitedPlayersCounter;

    private int playerPrevScore;

    public static int reviewMoveCounter;
    public static ArrayList<Integer> reviewedMoves;
    
    private String replyMessage;

//    private static ArrayList<ScrabbleServer> clientList = MultiThreadedScrabbleServer.getClientList();
    public void setCurrentPlayerIndex(int currentPlayerIndex){
        this.currentPlayerIndex = currentPlayerIndex;
    }

    public int getCurrentPlayerIndex(){return this.currentPlayerIndex;}

    public void setClientSocket(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }


    /**
     * Thread Execution
     *
     * - execute()
     * - readClientInput
     * - parseClientInput
     */


    public void execute(){
        // --Execute thread--
        //Obtain data streams.
        makeObjectStreams();
        //Initialize disconnect.
        this.disconnect = false;
        // Read connect message from client.
        JSONObject clientInput = readClientInput();
        String command = (String) clientInput.get("command");
        if (!command.equalsIgnoreCase("connect") | clientInput.size() != CONNECTMESSAGESIZE){
            System.out.println("Initial message is not connect.");
            return;
        }
        else{
            // Check player's name is unique
        	
        	String playerName = (String) clientInput.get("player");
        	boolean duplicateUserError = false;
        	
            for (int i = 0; i<currentPlayerNumber; i++){
                if (playerName.equalsIgnoreCase(lobbyPlayerList[i].getName())){
                    duplicateUserError = true;
                }
            }
            
            if (duplicateUserError == true)
            {
            	sendMessage("userexists");
            }
            else
            {
        	        	
        	// Player connected, add current player number.
            currentPlayerNumber++;
            // Create new scrabble player if max players not reached.
            if (currentPlayerNumber <= 4) {
                // send welcome message to newly connected client.
                sendMessage("Welcome to Scrabble!");
                // Add new client to client list.
                lobbyServerList[currentPlayerIndex] = this;

                // Add new player to player list.
                String name = (String) clientInput.get("player");
                lobbyPlayerList[currentPlayerIndex] = new Player(name);
                // set server's player object to the newly created player.
                player = lobbyPlayerList[currentPlayerIndex];
                player.setPlayerIndex(currentPlayerIndex);

                // Send new player list to client.
                sendPlayersList();
            }else{
                sendMessage("Max Players have been reached.");
                return;
            }

            // Continuously looping for client input.
            do{
                // Get client input
                clientInput = readClientInput();
                // Parse client input
                if (!clientInput.isEmpty()) {
                    parseClientInput(clientInput);
                }
            }while(!disconnect);
            }
         
        }
        close();
        // Reset scrabble game
//        scrabbleGame = new ScrabbleGame(new ProjectSpecificRule());
    }

    private JSONObject readClientInput(){
        // reads client input, checks for exceptions.
        JSONObject clientInput = new JSONObject();
        try {

            clientInput = (JSONObject) in.readObject();

        }catch(EOFException eofe){
            System.out.println("End of File Exception: Reading Client Input.");
        }catch(IOException ioe){
//            System.out.println("Unable to read client input object.");
        }catch(ClassNotFoundException cnfe){
            System.out.println("Client input object class not found.");
        }
        return clientInput;
    }

    private void parseClientInput(JSONObject clientInput) {
        //{command: connect, player: ____}
        //{command: disconnect, player: _____}
        //{command: move, player: _____, x: __, y: __, letter: __}

        String command = (String) clientInput.get("command");

        switch (command) {
            // Lobby
            case "disconnect":
                this.disconnect = true;
                // remove player from player list and server list and update.
                removePlayerfromList();
                // send updated player list to clients.
                sendPlayersList();
                break;
            // sends legal or illegal move message to client, if legal, the affected words too.
            case "invitePlayers":
                // sends invitation to all selected players from client.
                invitePlayers(clientInput);
                break;
            case "acceptPlayer":
                // parse accept player request, add player to acceptedPlayers list.
                acceptPlayer(clientInput);
                invitedPlayersCounter--;

                // run this after all players have sent a reply.
                if (invitedPlayersCounter <=0){
                    // check if number of game players > 2
                    if (gamePlayerList.size() < 2){
                        notEnoughPlayers();
                    }
                    else {
                        //start game
                        startGame();
                    }
                }
                break;
            // Game
            case "makePass":
            	makePassInGame();
            	sendGameLogMessage(player.getName() + " passed on their turn.");
            	   if (scrabbleGame.checkForGameEnd() != null)
                   {
            		   gameOver(scrabbleGame.checkForGameEnd());
                   }
                   else
                   {
                	   sendNextTurn();
                   }
                break;

            case "makeMove":
                // get player prev score
                playerPrevScore = this.player.getScore();
                System.out.println(playerPrevScore);
                // make move in the scrabble game.
                int result = makeMoveInGame(clientInput);
                if (result == 0){
                    
                	sendGameLogMessage(player.getName() + " made a move.");
                    // send updated board to all clients.
                    sendAllCurrentBoard();

                    reviewMoveCounter = gamePlayerList.size() - 1;
                    // sends move review message to all clients.
                    sendReviewTurnPlayerMessage();
                }else{
                    sendGameLogMessage(player.getName() + " made an illegal move. Try again.");
                    System.out.println("Unsuccessful in making move in game.");
                }
                break;
            case "reviewedMove":
                // parse reviews
                reviewedMoves = new ArrayList<>();
                parseReviewedMove(clientInput);
                System.out.println("reviewedMoves: " + reviewedMoves.toString());

                if (reviewMoveCounter <=0){
                    // check if reviews are all accept
                	int reviewResult = checkReviewedMoves();
                    if (reviewResult == 1) {
                        //send player list to all clients.
                        System.out.println("Review Passed.");
                        // Update the player list
                        for (int i = 0; i < currentPlayerNumber; i++) {
                            if (gamePlayerList.get(i).getName().equalsIgnoreCase(player.getName())) {
                            	gamePlayerList.get(i).setScore(player.getScore());
                            }
                        }


                        sendUpdateGameScoresList();
                        sendGameLogMessage("scores updated.");
                        sendUpdateGameScoresList();
                        
                        String scoreUpdateMsg;
                        scoreUpdateMsg = "They made a successful move."; 
                        sendGameLogMessage(scoreUpdateMsg);
                        
                        if (scrabbleGame.checkForGameEnd() != null) {
                            gameOver(scrabbleGame.checkForGameEnd());
                        } else {
                            sendNextTurn();
                        }

                        //send next turn;

                    }
                    else{
                        System.out.println("reviewMoves failed.");
                        //delete score
//                        int playerScore = player.getScore();
                        //player.setScore(playerPrevScore - playerScore);
                        for (int i = 0; i < currentPlayerNumber; i++) {
                            if (gamePlayerList.get(i).getName().equalsIgnoreCase(player.getName())) {
                                gamePlayerList.get(i).setScore(playerPrevScore);
                            }
                        }

                        this.player.setScore(playerPrevScore);
                        System.out.println(player.getScore());
                        
                        String notSuccessfulMsg = "Their move was unsuccessful."; 
                        sendGameLogMessage(notSuccessfulMsg);

                        if (scrabbleGame.checkForGameEnd() != null)
                        {
                        	gameOver(scrabbleGame.checkForGameEnd());
                        }
                        else
                        {
                        	sendNextTurn();
                        }
                    }
                }
                break;

            case "gameOver":
                // send message to all participating clients.
                endGameOnExit(clientInput);

        }
    }

    private void endGameOnExit(JSONObject clientInput){
        /*
        sends message to all participating client to end game.
         */
        JSONObject endGameMessage = new JSONObject();
        endGameMessage.put("command", "endGame");
        // highest score.
        Player topPlayer = getTopPlayer();
        String topPlayerName = topPlayer.getName();
        int topPlayerScore = topPlayer.getScore();
        endGameMessage.put("topPlayerName", topPlayerName);
        endGameMessage.put("topPlayerScore", topPlayerScore);

        sendAllClientsGame(endGameMessage, gameServerList, "end game message.", true);
    }

    private Player getTopPlayer(){
        int highestScore = -1;
        Player topPlayer = null;
        for (int i=0; i <gamePlayerList.size(); i++){
            if (gamePlayerList.get(i).getScore() >= highestScore){
                topPlayer = gamePlayerList.get(i);
            }
        }
        return topPlayer;
    }

    private void gameOver(Player highestScorer) {
        JSONObject gameOverMessage = new JSONObject();
        gameOverMessage.put("command", "gameOver");
        gameOverMessage.put("winner", highestScorer);
        sendAllClientsGame(gameOverMessage, gameServerList, "game over.", false);
    	
    	// TODO Auto-generated method stub
		
	}

	/**
     * Lobby Window
     *
     * - Connect            loginWindow
     * - Disconnect         [disconnect]
     * - InvitePlayers      [invitePlayers]
     * - acceptPlayer       [acceptPlayer]
     * - startGame          [acceptPlayer]
     * - notEnoughPlayers   [acceptPlayer]
     */
    // Connect & Disconnect
    private void sendPlayersList(){
        /*
        Constructs and sends new player list to client.
         */

        // construct new player list
        ArrayList<String> newPlayerList = new ArrayList<>();
        for (int i=0; i<currentPlayerNumber; i++){
            if (lobbyPlayerList[i] != null) {
                newPlayerList.add(lobbyPlayerList[i].getName());
            }
        }

        // construct new player list message.
        JSONObject newPlayerListMessage = new JSONObject();
        newPlayerListMessage.put("command", "updatePlayersList");
        newPlayerListMessage.put("newPlayersList", newPlayerList);

        // send player list to all clients.
        try{
            for (int i=0; i<currentPlayerNumber; i++){
                ObjectOutputStream clientOut = lobbyServerList[i].getOutputStream();
                clientOut.writeObject(newPlayerListMessage);
                clientOut.flush();
            }
        }catch(IOException ioe){
            System.out.println("IOException: Unable to send player list to client.");
        }
    }

    // Disconnect
    private void removePlayerfromList(){
        /*
        Shifts players if disconnecting player in the middle of Array.
        Otherwise, reduce the currentPlayerNumber.
         */
        //Update player list.
        if (this.currentPlayerIndex < currentPlayerNumber){
            for (int i = currentPlayerIndex; i < currentPlayerNumber-1; i++){
                // shift player list and scrabble server list down.
                lobbyPlayerList[i] = lobbyPlayerList[i+1];
                lobbyServerList[i] = lobbyServerList[i+1];
                // update player indices.
                int index;
                index = lobbyServerList[i].getCurrentPlayerIndex();
                lobbyServerList[i].setCurrentPlayerIndex(index-1);
                index = lobbyPlayerList[i].getPlayerIndex();
                lobbyPlayerList[i].setPlayerIndex(index-1);
            }
        }
        currentPlayerNumber--;
        System.out.println("currentPlayerNumber: " + currentPlayerNumber);
    }

    //InvitePlayers (command: invite)
    private void invitePlayers(JSONObject clientInput){
        /*
        Send invitation to invited players
         */
        ArrayList<String> invitedPlayersList = (ArrayList<String>) clientInput.get("invitedPlayersList");

        Player[] invitePlayers = findPlayerList(invitedPlayersList);
        ScrabbleServer[] inviteServers = findScrabbleServerList(invitePlayers);

        invitedPlayersCounter = invitePlayers.length - 1;
        System.out.println(invitedPlayersCounter);

        // instantiate and add own player object to list.
        gamePlayerList = new ArrayList<>();
        gamePlayerList.add(this.player);
        gameServerList = new ArrayList<>();
        gameServerList.add(this);
        // Construct invite message
        JSONObject inviteMessage = new JSONObject();
        inviteMessage.put("command", "invite");
        inviteMessage.put("inviter", player.getName());
        sendAllClientsLobby(inviteMessage, inviteServers, "Send game invites.");
    }

    //AcceptPlayers
    private void acceptPlayer(JSONObject clientInput) {
        /*
        Check client input for acceptance.
         */
        String playerName = (String) clientInput.get("acceptedPlayer");

        if (!playerName.equalsIgnoreCase("None")){
            // find player object and server object from player name;
            Player acceptedPlayer = findPlayer(playerName);
            int acceptedPlayerIndex = acceptedPlayer.getPlayerIndex();
            ScrabbleServer acceptedServer = findScrabbleServer(acceptedPlayerIndex);

            // update game player list and game server list.
            gamePlayerList.add(acceptedPlayer);
            gameServerList.add(acceptedServer);
        }
    }

    private void startGame(){
        /*
        Start new game, set game list of players, send all clients start game message.
         */

        // Make new scrabble game.
        scrabbleGame = new ScrabbleGame(new ProjectSpecificRule(), gamePlayerList.size());
        
        System.out.println("New Scrabble Game initiated.");

//        scrabbleGame.setListPlayer(gamePlayerList);
        try{
        for (int i=0 ; i<gamePlayerList.size(); i++){
            scrabbleGame.addPlayer(gamePlayerList.get(i));
        }}catch(InvalidNumberPlayersException inpe){
            System.out.println("InvalidNumberPlayersException when adding game players to game.");
        }

        // send all clients start game message.
        JSONObject startGameMessage = new JSONObject();
        startGameMessage.put("command", "startGame");
        sendAllClientsGame(startGameMessage, gameServerList, "start game message.", false);

        //send board to all clients including self.
        JSONObject initializeMessage = new JSONObject();
        initializeMessage.put("command", "initialize");
        char[][] initialBoard = getBoard();
        initializeMessage.put("initialBoard", initialBoard);
        initializeMessage.put("gamePlayerList", gamePlayerList);
        sendAllClientsGame(initializeMessage, gameServerList, "game initialization message", false);

        //send turn to all clients including self.
        JSONObject turnMessage = new JSONObject();
        turnMessage.put("command", "turn");
        Player turnPlayer = this.player;
        String turnPlayerName = turnPlayer.getName();
        turnMessage.put("turnPlayerName", turnPlayerName);
        sendAllClientsGame(turnMessage, gameServerList, "turn message.", false);

        sendGameLogMessage(turnPlayerName + "'s turn.");
    }

    private void notEnoughPlayers(){
        JSONObject notEnoughPlayersMessage = new JSONObject();

        notEnoughPlayersMessage.put("command", "notEnoughPlayers");
        try {
            out.writeObject(notEnoughPlayersMessage);
        }catch(IOException ioe){
            System.out.println("IOException: Unable to send not enough players message.");
        }
    }

    /*
    Helper functions
    */
    private void sendAllClientsLobby(JSONObject serverMessage, ScrabbleServer[] serverList, String errorCode){
        try{
            for (int i=0; i<serverList.length; i++){
                if (serverList[i] == this){
                    continue;
                }
                ObjectOutputStream clientOut = serverList[i].getOutputStream();
                clientOut.writeObject(serverMessage);
                clientOut.flush();
            }
        }catch(IOException ioe){
            System.out.println("IOException: " + errorCode);
        }
    }

    private void sendAllClientsGame(JSONObject serverMessage, ArrayList<ScrabbleServer> serverList, String errorCode, boolean skipSelf){
        /*
        Sends message to all clients.
        if skipSelf = true, skips sending message to self.
         */

        try{
            for (int i=0; i<serverList.size(); i++){
                if (skipSelf){
                    if (serverList.get(i) == this){
                        continue;
                    }
                }
                ObjectOutputStream clientOut = serverList.get(i).getOutputStream();
                clientOut.writeObject(serverMessage);
                clientOut.flush();
            }
        }catch(IOException ioe){
            System.out.println("IOException: " + errorCode);
            ioe.printStackTrace();
        }
    }

    private Player findPlayer(String playerName){
        /*
        Returns players object in lobbyPlayerList from player name.
         */

        for (int i = 0; i<currentPlayerNumber; i++){
            if (playerName.equalsIgnoreCase(lobbyPlayerList[i].getName())){
                return lobbyPlayerList[i];
            }
        }
        return null;
    }

    private Player[] findPlayerList(ArrayList<String> stringPlayersList){
        /*
        Return Player[] list from lobbyPlayerList with name.
         */
        Player[] gamePlayersList = new Player[stringPlayersList.size()];
        for (int i=0; i<stringPlayersList.size(); i++){
            for (int j = 0; j<currentPlayerNumber; j++){
                if (stringPlayersList.get(i).equalsIgnoreCase(lobbyPlayerList[j].getName())){
                    gamePlayersList[i] = lobbyPlayerList[j];
                }
            }
        }
        return gamePlayersList;
    }

    private ScrabbleServer findScrabbleServer(int playerIndex){
        for (int i = 0; i<currentPlayerNumber; i++){
            if (playerIndex == lobbyServerList[i].getCurrentPlayerIndex()){
                return lobbyServerList[i];
            }
        }
        return null;
    }

    private ScrabbleServer[] findScrabbleServerList(Player[] playerList){
        ScrabbleServer[] gameScrabbleServerList = new ScrabbleServer[playerList.length];

        for (int i = 0; i < playerList.length; i++){
            for (int j = 0; j < currentPlayerNumber; j++){
                if (playerList[i].getPlayerIndex() == lobbyServerList[j].getCurrentPlayerIndex()){
                    gameScrabbleServerList[i] = lobbyServerList[j];
                }
            }
        }
        return gameScrabbleServerList;
    }


    /**
     * GameWindow
     *
     * - makeMoveInGame                 [makeMove]
     * - sendAllCurrentBoard            [makeMove]
     * - sendReviewTurnPlayerMessage    [makeMove]
     * - parseReviewMove                [reviewedMove]
     * - checkReviewedMoves             [reviewedMove]
     *
     */
    // makeMove
    private int makeMoveInGame(JSONObject clientInput){
        /*
        Make move in scrabble game.
        Returns 0 if no error, 1 otherwise.
         */

        int x = (Integer) clientInput.get("x");
        int y = (Integer) clientInput.get("y");
        char letter = (Character) clientInput.get("letter");
        // Make move on scrabble game.
        try {
            scrabbleGame.makeMoveLetter(this.player, x, y, letter);
            replyMessage = "OK";
            return 0;

        }catch(NullPointerException npe) {
            System.out.println(npe.getMessage());
            replyMessage = npe.getMessage();
            return 1;
        }catch(InvalidMoveException ime) {
            replyMessage = ime.getMessage();
            System.out.println("Invalid move from " + this.player.getName() + ": " + replyMessage);

            return 1;
        }

    }
    
    private int makePassInGame(){
        scrabbleGame.passTurnWithoutMakingMove(this.player);
        return 0;
        }


    private void sendAllCurrentBoard(){
        char[][] board = getBoard();
        JSONObject updateBoardMessage = new JSONObject();

        updateBoardMessage.put("command", "updateBoard");
        updateBoardMessage.put("updatedBoard", board);

        sendAllClientsGame(updateBoardMessage, gameServerList, "sending current board.", false);
    }

    private void sendReviewTurnPlayerMessage(){
        /*
        Sends turn review to all clients except self.
         */
        JSONObject reviewTurnPlayerMessage = new JSONObject();
        reviewTurnPlayerMessage.put("command", "reviewTurnPlayer");
        String turnPlayerName = this.player.getName();
        reviewTurnPlayerMessage.put("turnPlayerName", turnPlayerName);
        ArrayList <String> affectedWords = scrabbleGame.getWordsMadeLastMove();
        reviewTurnPlayerMessage.put("affectedWords", affectedWords);

        sendAllClientsGame(reviewTurnPlayerMessage, gameServerList, "sending reviewTurnPlayerMessage.", true);
    }

    // reviewedMove
    private void parseReviewedMove(JSONObject clientInput){
        /*
        parse client review from turnPlayer's turn.
         */
        reviewMoveCounter--;
        int review = (Integer) clientInput.get("reviewedMove");
        reviewedMoves.add(review);
    }

    private int checkReviewedMoves(){
        /*
        Check reviewed moves, all must pass for player to score.
         */
        for (int i=0; i<reviewedMoves.size(); i++){
            if (reviewedMoves.get(i) <= 0){
                return 0;
            }
        }
        return 1;
    }

    private void sendUpdateGameScoresList(){
        /*
        Sends updated game player list to all clients including self.
         */
        JSONObject updateGamePlayersListMessage = new JSONObject();
        updateGamePlayersListMessage.put("command","updateScore");

        for (int i=0; i<gamePlayerList.size(); i++) {
            System.out.println("Score change on server:" + gamePlayerList.get(i).getScore());
        }

//        ArrayList<Player> updatedPlayersList = scrabbleGame.getListOfPlayers();

        ArrayList<Integer> gamePlayerScoresList = new ArrayList<>();

        for (int i=0; i<gamePlayerList.size(); i++){
            gamePlayerScoresList.add(gamePlayerList.get(i).getScore());
            System.out.println("Score change on client:"+gamePlayerList.get(i).getScore());
        }

//        updateGamePlayersListMessage.put("updatedGamePlayersList", gamePlayerList);
        updateGamePlayersListMessage.put("updatedGameScoresList", gamePlayerScoresList);
        sendAllClientsGame(updateGamePlayersListMessage, gameServerList, "update game player list message", false);
    }

    private void sendNextTurn(){
        Player turnPlayer = scrabbleGame.getTurnPlayer();

        JSONObject nextTurnMessage = new JSONObject();
        nextTurnMessage.put("command", "turn");
        nextTurnMessage.put("turnPlayerName", turnPlayer.getName());
        System.out.println(nextTurnMessage);
        sendAllClientsGame(nextTurnMessage, gameServerList,"sending turn message.", false);
    }

    private void sendGameLogMessage(String message){
        JSONObject gameLogMessage = new JSONObject();

        gameLogMessage.put("command", "gamelogmessage");
        gameLogMessage.put("message", message);

        sendAllClientsGame(gameLogMessage, gameServerList, "send gamelogmessage.", false);
    }



    /**
     * Misc. Helper functions
     */

    private void sendMessage(String message){
        try {
            JSONObject messageReply = new JSONObject();
            messageReply.put("message", message);
            out.writeObject(messageReply);
        }catch(IOException ioe){
            System.out.println("Unable to send welcome message to client.");
        }
    }


    private void makeObjectStreams(){
        try {
            in = new ObjectInputStream(clientSocket.getInputStream());
            out = new ObjectOutputStream(clientSocket.getOutputStream());
        }catch(IOException ioe){
            System.out.println("Unable to get Object streams from client.");
        }
    }

    private ObjectOutputStream getOutputStream(){
        return this.out;
    }

    private char[][] getBoard(){
        char[][] board = scrabbleGame.getBoard().getLettersOnBoard();
        return board;
    }


    private void close(){
        try{
            in.close();
            out.close();
            clientSocket.close();
        }catch(IOException ioe){
            System.out.println("Unable to close socket and IO streams from " + this.player);
        }
    }

}

