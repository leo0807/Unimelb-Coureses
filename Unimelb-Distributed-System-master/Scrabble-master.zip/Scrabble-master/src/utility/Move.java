package utility;

import game.Player;

//Perhaps move this class back to the "game" package?

//This class represents players' changes to board, mainly used for JSON parser (sending message from client to server or server to client) and ScrabbleGame
public class Move {
	private Player player;
	private int x;
	private int y;
	private char letter;
	
	public Move(Player player, int x, int y, char letter) {
		this.x = x;
		this.y = y;
		this.player = player;
		this.letter = letter;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public Player getPlayer() {
		return player;
	}

	public char getLetter() {
		return letter;
	}
	
	
	
}
