# WSTA_fact_checker
Fact checker for web text
